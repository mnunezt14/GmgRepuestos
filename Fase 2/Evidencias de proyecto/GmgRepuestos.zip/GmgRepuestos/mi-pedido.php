<?php
require_once 'backend/config.php';

/**
 * Normaliza un RUT chileno para comparar sin importar puntos, guion,
 * mayúsculas/minúsculas ni espacios (ej. "21.740.488-6" y "217404886"
 * se consideran el mismo RUT).
 */
function miPedidoNormalizarRut($rut) {
    $rut = strtoupper(trim($rut));
    return preg_replace('/[^0-9K]/', '', $rut);
}

$numeroPedido = isset($_GET['numero']) ? trim($_GET['numero']) : '';
$rutIngresado = isset($_GET['rut']) ? trim($_GET['rut']) : '';
$buscado = ($numeroPedido !== '' || $rutIngresado !== '');

$pedido = null;
$items = [];
$error = '';

if ($buscado) {
    $idPedido = (int)$numeroPedido;
    if ($idPedido <= 0 || $rutIngresado === '') {
        $error = 'Ingresa tu número de pedido y tu RUT para buscar.';
    } else {
        $stmt = $conexion->prepare("SELECT * FROM pedidos WHERE id = ? LIMIT 1");
        $stmt->bind_param("i", $idPedido);
        $stmt->execute();
        $res = $stmt->get_result();
        $filaPedido = $res->fetch_assoc();
        $stmt->close();

        // Comparación de RUT normalizada, para no depender del formato con
        // que el cliente lo escriba. No se distingue si falló el número o
        // el RUT en el mensaje de error, para no dar pistas de qué pedidos
        // existen a quien solo esté adivinando.
        if ($filaPedido && miPedidoNormalizarRut($filaPedido['rut_cliente']) === miPedidoNormalizarRut($rutIngresado) && miPedidoNormalizarRut($rutIngresado) !== '') {
            $pedido = $filaPedido;
            $stmtItems = $conexion->prepare("SELECT * FROM pedido_items WHERE pedido_id = ?");
            $stmtItems->bind_param("i", $idPedido);
            $stmtItems->execute();
            $resItems = $stmtItems->get_result();
            while ($fila = $resItems->fetch_assoc()) {
                $items[] = $fila;
            }
            $stmtItems->close();
        } else {
            $error = 'No encontramos un pedido con ese número y RUT. Revisa que ambos estén correctos.';
        }
    }
}

function miPedidoBadge($valor, $tipo) {
    $clasesEstado = [
        'aprobado' => 'badge-aprobado',
        'pendiente' => 'badge-pendiente',
        'rechazado' => 'badge-rechazado',
        'error' => 'badge-error',
    ];
    $clasesPago = [
        'recibido' => 'badge-aprobado',
        'pendiente' => 'badge-pendiente',
        'rechazado' => 'badge-rechazado',
    ];
    $etiquetasPago = [
        'recibido' => 'Pago recibido',
        'pendiente' => 'Sin pago',
        'rechazado' => 'Pago rechazado',
    ];
    if ($tipo === 'pago') {
        $valor = $valor ?: 'pendiente';
        $clase = $clasesPago[$valor] ?? 'badge-pendiente';
        $texto = $etiquetasPago[$valor] ?? ucfirst($valor);
    } else {
        $clase = $clasesEstado[$valor] ?? 'badge-pendiente';
        $texto = ucfirst($valor);
    }
    return '<span class="badge ' . $clase . '">' . htmlspecialchars($texto) . '</span>';
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Estado de mi pedido - GMG Repuestos</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/admin.css">
    <style>
        .seguimiento-container {
            max-width: 620px;
            margin: 50px auto;
            background: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .seguimiento-container h2 {
            margin-top: 0;
        }
        .seguimiento-form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 14px;
            margin: 18px 0;
        }
        .seguimiento-form-row label {
            display: block;
            font-size: 0.82rem;
            color: #666;
            margin-bottom: 4px;
        }
        .seguimiento-form-row input {
            width: 100%;
            padding: 10px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 0.95rem;
        }
        .seguimiento-error {
            background: #fdecea;
            color: #D32F2F;
            padding: 12px 14px;
            border-radius: 4px;
            font-size: 0.88rem;
            margin-bottom: 16px;
        }
        .seguimiento-detalle {
            margin-top: 26px;
            border-top: 1px solid #eee;
            padding-top: 20px;
        }
        .seguimiento-items-table {
            width: 100%;
            border-collapse: collapse;
            margin: 14px 0;
            font-size: 0.9rem;
        }
        .seguimiento-items-table th, .seguimiento-items-table td {
            text-align: left;
            padding: 8px 4px;
            border-bottom: 1px solid #eee;
        }
        .seguimiento-items-table th:not(:first-child), .seguimiento-items-table td:not(:first-child) {
            text-align: right;
        }
    </style>
</head>
<body>
    <header>
        <div class="container nav-container">
            <a href="index.php" class="logo">GMG <span>Repuestos</span></a>
            <nav>
                <ul>
                    <li><a href="index.php">Inicio</a></li>
                    <li><a href="mi-pedido.php">Mi pedido</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main class="container">
        <div class="seguimiento-container">
            <h2>Estado de mi pedido</h2>
            <p style="color:#666; font-size:0.9rem;">Ingresa tu número de pedido (te lo mostramos al terminar tu compra) y tu RUT para ver en qué va.</p>

            <?php if ($error): ?>
                <div class="seguimiento-error"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>

            <form method="GET" action="mi-pedido.php">
                <div class="seguimiento-form-row">
                    <div>
                        <label for="numero">Número de pedido</label>
                        <input type="number" min="1" id="numero" name="numero" placeholder="Ej: 5" value="<?php echo htmlspecialchars($numeroPedido); ?>" required>
                    </div>
                    <div>
                        <label for="rut">RUT</label>
                        <input type="text" id="rut" name="rut" placeholder="Ej: 12.345.678-9" value="<?php echo htmlspecialchars($rutIngresado); ?>" required>
                    </div>
                </div>
                <button type="submit" class="btn-admin" style="background:#111; color:#fff; border-color:#111;">Buscar pedido</button>
            </form>

            <?php if ($pedido): ?>
                <div class="seguimiento-detalle">
                    <p><strong>Pedido #<?php echo (int)$pedido['id']; ?></strong> — <?php echo htmlspecialchars(date('d-m-Y H:i', strtotime($pedido['fecha']))); ?></p>
                    <p>
                        Estado del pedido: <?php echo miPedidoBadge($pedido['estado'], 'estado'); ?>
                        &nbsp; Pago: <?php echo miPedidoBadge($pedido['pago_estado'] ?? 'pendiente', 'pago'); ?>
                    </p>

                    <table class="seguimiento-items-table">
                        <thead>
                            <tr><th>Producto</th><th>Cant.</th><th>Precio</th><th>Subtotal</th></tr>
                        </thead>
                        <tbody>
                            <?php foreach ($items as $item): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($item['nombre_producto']); ?></td>
                                    <td><?php echo (int)$item['cantidad']; ?></td>
                                    <td>$<?php echo number_format($item['precio_unitario'], 0, ',', '.'); ?></td>
                                    <td>$<?php echo number_format($item['precio_unitario'] * $item['cantidad'], 0, ',', '.'); ?></td>
                                </tr>
                            <?php endforeach; ?>
                            <?php if (empty($items)): ?>
                                <tr><td colspan="4" style="color:#999;">Sin productos registrados.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>

                    <p style="text-align:right; font-size:1.05rem;"><strong>Total: $<?php echo number_format($pedido['total'], 0, ',', '.'); ?></strong></p>

                    <?php if ($pedido['estado'] === 'pendiente'): ?>
                        <p style="color:#888; font-size:0.88rem;">Tu pedido está siendo revisado por nuestro equipo. Te avisaremos por correo apenas cambie de estado.</p>
                    <?php elseif ($pedido['estado'] === 'rechazado'): ?>
                        <p style="color:#888; font-size:0.88rem;">Este pedido fue rechazado. Si tienes dudas, escríbenos por WhatsApp.</p>
                    <?php endif; ?>

                    <a href="https://wa.me/56900000000?text=Hola,%20quiero%20consultar%20por%20mi%20pedido%20%23<?php echo (int)$pedido['id']; ?>" class="btn-volver" style="display:inline-block; background:#25D366; color:#fff; padding:10px 20px; text-decoration:none; border-radius:4px; font-weight:bold; margin-top:14px;">Consultar por WhatsApp</a>
                </div>
            <?php endif; ?>
        </div>
    </main>
</body>
</html>
