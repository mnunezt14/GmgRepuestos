<?php
require_once '../backend/auth.php';
requerirAdmin('../');
require_once '../backend/config.php';

$mensajeFlash = '';
$tipoMensajeFlash = '';

// --- Marcar un aviso de stock como notificado ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['accion'] ?? '') === 'marcar_notificado') {
    $id = (int)($_POST['id'] ?? 0);
    if ($id > 0) {
        $stmt = $conexion->prepare("UPDATE avisos_stock SET notificado = 1 WHERE id_aviso = ?");
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) {
            $mensajeFlash = 'Aviso #' . $id . ' marcado como notificado.';
            $tipoMensajeFlash = 'exito';
        } else {
            $mensajeFlash = 'No se pudo actualizar el aviso.';
            $tipoMensajeFlash = 'error';
        }
        $stmt->close();
    }
}

// --- ¿Existen las tablas del chatbot? (por si no se ha corrido la migración v3) ---
$tablasListas = true;
$chk = $conexion->query("SHOW TABLES LIKE 'conversaciones_chat'");
if (!$chk || $chk->num_rows === 0) {
    $tablasListas = false;
}

$totalConversaciones = 0;
$totalMensajes = 0;
$feedbackPositivo = 0;
$feedbackNegativo = 0;
$avisosPendientes = 0;
$conversaciones = [];
$mensajesPorConversacion = [];
$avisos = [];

if ($tablasListas) {
    $r = $conexion->query("SELECT COUNT(*) AS c FROM conversaciones_chat");
    if ($r) { $totalConversaciones = (int)$r->fetch_assoc()['c']; }

    $r = $conexion->query("SELECT COUNT(*) AS c FROM mensajes_chat");
    if ($r) { $totalMensajes = (int)$r->fetch_assoc()['c']; }

    $r = $conexion->query("SELECT COUNT(*) AS c FROM mensajes_chat WHERE feedback = 'positivo'");
    if ($r) { $feedbackPositivo = (int)$r->fetch_assoc()['c']; }

    $r = $conexion->query("SELECT COUNT(*) AS c FROM mensajes_chat WHERE feedback = 'negativo'");
    if ($r) { $feedbackNegativo = (int)$r->fetch_assoc()['c']; }

    $r = $conexion->query("SELECT COUNT(*) AS c FROM avisos_stock WHERE notificado = 0");
    if ($r) { $avisosPendientes = (int)$r->fetch_assoc()['c']; }

    // --- Últimas 30 conversaciones ---
    $r = $conexion->query("
        SELECT c.id_conversacion AS id, c.sesion_id, c.creado_en, c.ultimo_mensaje_en,
               (SELECT COUNT(*) FROM mensajes_chat m WHERE m.id_conversacion = c.id_conversacion) AS num_mensajes
        FROM conversaciones_chat c
        ORDER BY c.ultimo_mensaje_en DESC
        LIMIT 30
    ");
    if ($r) {
        while ($fila = $r->fetch_assoc()) {
            $conversaciones[] = $fila;
        }
    }

    if (count($conversaciones) > 0) {
        $ids = array_map(fn($c) => (int)$c['id'], $conversaciones);
        $idsList = implode(',', $ids);
        $r = $conexion->query("SELECT id_mensaje AS id, id_conversacion AS conversacion_id, rol, contenido, feedback, creado_en FROM mensajes_chat WHERE id_conversacion IN ($idsList) ORDER BY creado_en ASC, id_mensaje ASC");
        if ($r) {
            while ($fila = $r->fetch_assoc()) {
                $mensajesPorConversacion[$fila['conversacion_id']][] = $fila;
            }
        }
    }

    // --- Avisos de stock pendientes ---
    $r = $conexion->query("
        SELECT a.id_aviso AS id, a.contacto, a.creado_en, a.notificado, p.nombre AS producto_nombre, p.stock
        FROM avisos_stock a
        LEFT JOIN repuestos p ON p.id_repuesto = a.id_repuesto
        ORDER BY a.notificado ASC, a.creado_en DESC
        LIMIT 50
    ");
    if ($r) {
        while ($fila = $r->fetch_assoc()) {
            $avisos[] = $fila;
        }
    }
}

function badgeFeedback($feedback) {
    if ($feedback === 'positivo') return '<span class="badge badge-aprobado">👍</span>';
    if ($feedback === 'negativo') return '<span class="badge badge-error">👎</span>';
    return '';
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat IA - Panel administrador - GMG Repuestos</title>
    <meta name="robots" content="noindex, nofollow">
    <link rel="stylesheet" href="../css/style.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="../css/admin.css?v=<?php echo time(); ?>">
</head>
<body class="admin-body">

    <div class="admin-topbar">
        <div class="container">
            <div class="admin-brand">GMG <span>Admin</span></div>
            <nav class="admin-nav">
                <a href="index.php">Dashboard</a>
                <a href="productos.php">Productos</a>
                <a href="pedidos.php">Pedidos</a>
                <a href="codigos.php">Códigos</a>
                <a href="conversaciones.php" class="active">Chat IA</a>
                <span class="admin-user">Hola, <?php echo htmlspecialchars(nombreAdminActual()); ?></span>
                <a href="../logout.php" class="admin-logout">Cerrar sesión</a>
            </nav>
        </div>
    </div>

    <main class="admin-main">
        <div class="container">
            <div class="admin-heading">
                <h1>Analítica del Chat IA</h1>
            </div>

            <?php if ($mensajeFlash): ?>
                <div class="flash-msg flash-<?php echo $tipoMensajeFlash; ?>"><?php echo htmlspecialchars($mensajeFlash); ?></div>
            <?php endif; ?>

            <?php if (!$tablasListas): ?>
                <div class="flash-msg flash-error">
                    Todavía no se ha ejecutado la migración de base de datos del Chat IA.
                    Corre el archivo <strong>BD_v2/01_estructura.sql</strong> en phpMyAdmin
                    para activar el registro de conversaciones y esta pantalla.
                </div>
            <?php else: ?>

            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-label">Conversaciones</div>
                    <div class="stat-value"><?php echo $totalConversaciones; ?></div>
                </div>
                <div class="stat-card">
                    <div class="stat-label">Mensajes totales</div>
                    <div class="stat-value"><?php echo $totalMensajes; ?></div>
                </div>
                <div class="stat-card">
                    <div class="stat-label">Feedback 👍</div>
                    <div class="stat-value"><?php echo $feedbackPositivo; ?></div>
                </div>
                <div class="stat-card">
                    <div class="stat-label">Feedback 👎</div>
                    <div class="stat-value"><?php echo $feedbackNegativo; ?></div>
                </div>
                <div class="stat-card">
                    <div class="stat-label">Avisos de stock pendientes</div>
                    <div class="stat-value"><?php echo $avisosPendientes; ?></div>
                </div>
            </div>

            <div class="admin-heading">
                <h1>Últimas conversaciones</h1>
            </div>

            <div class="admin-panel">
                <div class="admin-table-wrap">
                    <?php if (count($conversaciones) === 0): ?>
                        <p class="admin-empty">Todavía no hay conversaciones registradas.</p>
                    <?php else: ?>
                        <table class="admin-table">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Sesión</th>
                                    <th>Inicio</th>
                                    <th>Último mensaje</th>
                                    <th>Mensajes</th>
                                    <th>Detalle</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($conversaciones as $c): ?>
                                <tr>
                                    <td>#<?php echo (int)$c['id']; ?></td>
                                    <td><span style="font-family:monospace; font-size:0.8rem;"><?php echo htmlspecialchars(substr($c['sesion_id'], 0, 14)); ?>…</span></td>
                                    <td><?php echo htmlspecialchars(date('d-m-Y H:i', strtotime($c['creado_en']))); ?></td>
                                    <td><?php echo htmlspecialchars(date('d-m-Y H:i', strtotime($c['ultimo_mensaje_en']))); ?></td>
                                    <td><?php echo (int)$c['num_mensajes']; ?></td>
                                    <td>
                                        <button type="button" class="link-editar toggle-detalle" data-id="<?php echo (int)$c['id']; ?>">Ver mensajes</button>
                                    </td>
                                </tr>
                                <tr id="detalle-<?php echo (int)$c['id']; ?>" class="pedido-items-row" style="display:none;">
                                    <td colspan="6">
                                        <ul class="pedido-items-list">
                                            <?php foreach (($mensajesPorConversacion[$c['id']] ?? []) as $m): ?>
                                                <li>
                                                    <strong><?php echo $m['rol'] === 'bot' ? '🤖 Asistente' : '🧑 Cliente'; ?></strong>
                                                    <?php echo badgeFeedback($m['feedback']); ?>
                                                    — <?php echo htmlspecialchars($m['contenido']); ?>
                                                    <span style="color:#999; font-size:0.75rem;"> (<?php echo htmlspecialchars(date('d-m-Y H:i', strtotime($m['creado_en']))); ?>)</span>
                                                </li>
                                            <?php endforeach; ?>
                                            <?php if (empty($mensajesPorConversacion[$c['id']])): ?>
                                                <li>Sin mensajes registrados.</li>
                                            <?php endif; ?>
                                        </ul>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>

            <div class="admin-heading">
                <h1>Avisos de stock solicitados</h1>
            </div>

            <div class="admin-panel">
                <div class="admin-table-wrap">
                    <?php if (count($avisos) === 0): ?>
                        <p class="admin-empty">No hay clientes esperando aviso de stock.</p>
                    <?php else: ?>
                        <table class="admin-table">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Producto</th>
                                    <th>Stock actual</th>
                                    <th>Contacto</th>
                                    <th>Solicitado</th>
                                    <th>Estado</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($avisos as $a): ?>
                                <tr>
                                    <td>#<?php echo (int)$a['id']; ?></td>
                                    <td><?php echo htmlspecialchars($a['producto_nombre'] ?? '(producto eliminado)'); ?></td>
                                    <td><?php echo isset($a['stock']) ? (int)$a['stock'] : '—'; ?></td>
                                    <td><?php echo htmlspecialchars($a['contacto']); ?></td>
                                    <td><?php echo htmlspecialchars(date('d-m-Y H:i', strtotime($a['creado_en']))); ?></td>
                                    <td>
                                        <?php if ($a['notificado']): ?>
                                            <span class="badge badge-aprobado">Notificado</span>
                                        <?php else: ?>
                                            <span class="badge badge-pendiente">Pendiente</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if (!$a['notificado']): ?>
                                        <form method="POST" action="conversaciones.php" style="display:inline;">
                                            <input type="hidden" name="accion" value="marcar_notificado">
                                            <input type="hidden" name="id" value="<?php echo (int)$a['id']; ?>">
                                            <button type="submit" class="btn-admin btn-secundario">Marcar notificado</button>
                                        </form>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>

            <?php endif; ?>
        </div>
    </main>

    <script>
        document.querySelectorAll('.toggle-detalle').forEach(function (btn) {
            btn.addEventListener('click', function () {
                var fila = document.getElementById('detalle-' + btn.dataset.id);
                if (fila) {
                    fila.style.display = (fila.style.display === 'table-row') ? 'none' : 'table-row';
                }
            });
        });
    </script>
</body>
</html>
