<?php
header('Content-Type: application/json; charset=utf-8');
require_once 'backend/config.php';
require_once 'backend/email_helpers.php';

$input = file_get_contents('php://input');
$data = json_decode($input, true);

if (!$data || !isset($data['items']) || empty($data['items'])) {
    echo json_encode(['success' => false, 'message' => 'Carrito vacío']);
    exit;
}

// --- Datos del cliente (obligatorios; GMG Repuestos no hace envíos,
//     por eso NO se pide dirección, solo datos de contacto) ---
$cliente = $data['cliente'] ?? [];
$nombreCliente = trim($cliente['nombre'] ?? '');
$apellidoCliente = trim($cliente['apellido'] ?? '');
$rutCliente = trim($cliente['rut'] ?? '');
$telefonoCliente = trim($cliente['telefono'] ?? '');
$emailCliente = trim($cliente['email'] ?? '');

if ($nombreCliente === '' || $apellidoCliente === '' || $rutCliente === '' || $telefonoCliente === '' || $emailCliente === '') {
    echo json_encode(['success' => false, 'message' => 'Faltan datos del cliente (nombre, apellido, RUT, teléfono y correo son obligatorios).']);
    exit;
}

if (!filter_var($emailCliente, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['success' => false, 'message' => 'El correo electrónico ingresado no es válido.']);
    exit;
}

// Extraer IDs para consultar
$itemsSolicitados = $data['items'];
$ids = array_map(function($item) { return (int)$item['id']; }, $itemsSolicitados);
$idsList = implode(',', $ids);

$sql = "SELECT id, nombre, precio, imagen_url FROM productos WHERE id IN ($idsList)";
$resultado = $conexion->query($sql);

$productosDb = [];
if ($resultado && $resultado->num_rows > 0) {
    while ($fila = $resultado->fetch_assoc()) {
        $productosDb[$fila['id']] = $fila;
    }
}

$mpItems = [];
foreach ($itemsSolicitados as $itemReq) {
    $id = (int)$itemReq['id'];
    if (isset($productosDb[$id])) {
        $cantidad = (int)$itemReq['quantity'];
        if ($cantidad > 0) {
            $mpItems[] = [
                "id" => (string)$id,
                "title" => $productosDb[$id]['nombre'],
                "description" => "Repuesto Suzuki",
                "picture_url" => $productosDb[$id]['imagen_url'],
                "quantity" => $cantidad,
                "currency_id" => "CLP",
                "unit_price" => (float)$productosDb[$id]['precio']
            ];
        }
    }
}

if (count($mpItems) === 0) {
    echo json_encode(['success' => false, 'message' => 'Monto o productos inválidos']);
    exit;
}

$subtotalPedido = 0;
foreach ($mpItems as $mpItem) {
    $subtotalPedido += $mpItem['unit_price'] * $mpItem['quantity'];
}

// --- Código de descuento (opcional). Se vuelve a validar en el
//     servidor: nunca se confía en el descuento que venga del navegador. ---
$codigoDescuento = trim($data['codigo_descuento'] ?? '');
$montoDescuento = 0;

if ($codigoDescuento !== '') {
    $stmtCod = $conexion->prepare("SELECT tipo, valor FROM codigos_descuento WHERE codigo = ? AND activo = 1 LIMIT 1");
    $stmtCod->bind_param("s", $codigoDescuento);
    $stmtCod->execute();
    $resCod = $stmtCod->get_result();
    if ($resCod && $resCod->num_rows === 1) {
        $filaCod = $resCod->fetch_assoc();
        if ($filaCod['tipo'] === 'porcentaje') {
            $montoDescuento = $subtotalPedido * ((float)$filaCod['valor'] / 100);
        } else {
            $montoDescuento = (float)$filaCod['valor'];
        }
        if ($montoDescuento > $subtotalPedido) {
            $montoDescuento = $subtotalPedido;
        }
        $montoDescuento = round($montoDescuento);
    } else {
        // Código inválido: se ignora silenciosamente el descuento (no se
        // bloquea la compra), el total final ya no lo incluye.
        $codigoDescuento = '';
    }
    $stmtCod->close();
}

$totalPedido = $subtotalPedido - $montoDescuento;

// Si hay descuento, se prorratea sobre cada línea de producto para que
// Mercado Pago cobre exactamente el total con descuento (MP no admite
// líneas de precio negativo para mostrar el descuento como ítem aparte).
if ($montoDescuento > 0 && $subtotalPedido > 0) {
    $factor = $totalPedido / $subtotalPedido;
    $acumulado = 0;
    foreach ($mpItems as $i => $mpItem) {
        $esUltimo = ($i === count($mpItems) - 1);
        if ($esUltimo) {
            // Ajusta el último ítem para que la suma cuadre exacta (evita
            // diferencias de $1-2 por redondeo).
            $lineaTotal = $totalPedido - $acumulado;
        } else {
            $lineaTotal = round(($mpItem['unit_price'] * $mpItem['quantity']) * $factor);
            $acumulado += $lineaTotal;
        }
        $mpItems[$i]['unit_price'] = $mpItem['quantity'] > 0 ? round($lineaTotal / $mpItem['quantity'], 2) : $mpItem['unit_price'];
    }
}

// Registrar el pedido en la base de datos ANTES de contactar a Mercado Pago,
// para tener un id que el panel de administración pueda mostrar y para
// poder marcarlo como aprobado/rechazado cuando el cliente vuelva del pago.
$pedidoId = 0;
$stmtPedido = $conexion->prepare("INSERT INTO pedidos (estado, metodo_pago, total, nombre_cliente, apellido_cliente, rut_cliente, telefono_cliente, email_cliente, codigo_descuento, descuento_monto) VALUES ('pendiente', 'Mercado Pago', ?, ?, ?, ?, ?, ?, ?, ?)");
$codigoParaGuardar = $codigoDescuento !== '' ? $codigoDescuento : null;
$stmtPedido->bind_param("dssssssd", $totalPedido, $nombreCliente, $apellidoCliente, $rutCliente, $telefonoCliente, $emailCliente, $codigoParaGuardar, $montoDescuento);
if ($stmtPedido->execute()) {
    $pedidoId = $conexion->insert_id;
    $stmtItem = $conexion->prepare("INSERT INTO pedido_items (pedido_id, producto_id, nombre_producto, cantidad, precio_unitario) VALUES (?, ?, ?, ?, ?)");
    foreach ($mpItems as $mpItem) {
        $productoId = (int)$mpItem['id'];
        $nombreProducto = $mpItem['title'];
        $cantidad = (int)$mpItem['quantity'];
        // Se guarda el precio original (sin descuento) para que el detalle
        // del pedido en el panel admin muestre precios de catálogo reales.
        $precioUnitario = (float)$productosDb[$productoId]['precio'];
        $stmtItem->bind_param("iisid", $pedidoId, $productoId, $nombreProducto, $cantidad, $precioUnitario);
        $stmtItem->execute();
    }
    $stmtItem->close();

    // Aviso al administrador: pedido nuevo esperando revisión y aprobación.
    // Si el correo falla (SMTP mal configurado, etc.) no debe interrumpir
    // el checkout, por eso se ignora silenciosamente cualquier error aquí.
    enviarCorreoNuevoPedido($conexion, $pedidoId);
}
$stmtPedido->close();

// Preparar solicitud a Mercado Pago
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
$domainName = $_SERVER['HTTP_HOST'];
$scriptPath = dirname($_SERVER['SCRIPT_NAME']);
$scriptPath = rtrim($scriptPath, '/\\');
$base_url = $protocol . $domainName . $scriptPath;

$payload = [
    "items" => $mpItems,
    "payer" => [
        "name" => $nombreCliente,
        "surname" => $apellidoCliente,
        "phone" => [
            "number" => $telefonoCliente
        ]
    ],
    "external_reference" => (string)$pedidoId,
    "back_urls" => [
        "success" => $base_url . "/mercadopago_return.php?status=success&pedido_id=" . $pedidoId,
        "failure" => $base_url . "/mercadopago_return.php?status=failure&pedido_id=" . $pedidoId,
        "pending" => $base_url . "/mercadopago_return.php?status=pending&pedido_id=" . $pedidoId
    ],
    "auto_return" => "approved",
    "payment_methods" => [
        "installments" => 6
    ],
    "statement_descriptor" => "GMG REPUESTOS"
];

$url = 'https://api.mercadopago.com/checkout/preferences';

$ch = curl_init($url);
curl_setopt_array($ch, [
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => json_encode($payload),
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_HTTPHEADER => [
        'Content-Type: application/json',
        'Authorization: Bearer ' . MP_ACCESS_TOKEN
    ]
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$error = curl_error($ch);
curl_close($ch);

if ($error || $httpCode >= 400 || empty($response)) {
    if ($pedidoId > 0) {
        $stmtErr = $conexion->prepare("UPDATE pedidos SET estado = 'error' WHERE id = ?");
        $stmtErr->bind_param("i", $pedidoId);
        $stmtErr->execute();
        $stmtErr->close();
    }
    echo json_encode(['success' => false, 'message' => 'Error al contactar con Mercado Pago (' . $httpCode . ')']);
    exit;
}

$decoded = json_decode($response, true);
if (isset($decoded['init_point'])) {
    if ($pedidoId > 0 && isset($decoded['id'])) {
        $preferenceId = $decoded['id'];
        $stmtRef = $conexion->prepare("UPDATE pedidos SET referencia_pago = ? WHERE id = ?");
        $stmtRef->bind_param("si", $preferenceId, $pedidoId);
        $stmtRef->execute();
        $stmtRef->close();
    }
    echo json_encode([
        'success' => true,
        'init_point' => $decoded['init_point']
    ]);
} else {
    if ($pedidoId > 0) {
        $stmtErr = $conexion->prepare("UPDATE pedidos SET estado = 'error' WHERE id = ?");
        $stmtErr->bind_param("i", $pedidoId);
        $stmtErr->execute();
        $stmtErr->close();
    }
    echo json_encode(['success' => false, 'message' => 'Respuesta inesperada de Mercado Pago']);
}
?>
