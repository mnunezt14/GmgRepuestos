<?php
require_once 'backend/config.php';

$status = isset($_GET['status']) ? $_GET['status'] : 'unknown';
$payment_id = isset($_GET['payment_id']) ? $_GET['payment_id'] : '';
$payment_type = isset($_GET['payment_type']) ? $_GET['payment_type'] : '';
$pedido_id = isset($_GET['pedido_id']) ? (int)$_GET['pedido_id'] : 0;

$aprobado = false;
$estado_mensaje = "Transacción no procesada";
$pagoEstado = 'rechazado';

if ($status === 'approved' || $status === 'success') {
    $aprobado = true;
    $estado_mensaje = "¡Pago exitoso! Hemos recibido tu orden de compra y ahora está en revisión.";
    $pagoEstado = 'recibido';
} elseif ($status === 'pending') {
    $estado_mensaje = "Tu pago está pendiente de confirmación.";
    $pagoEstado = 'pendiente';
} else {
    $estado_mensaje = "El pago fue rechazado o anulado. Inténtalo nuevamente.";
    $pagoEstado = 'rechazado';
}

// Registrar el resultado del PAGO en un campo aparte (pago_estado). El
// campo "estado" del pedido (Pendiente/Aprobado/Rechazado) es la revisión
// manual del administrador y a propósito NO se toca aquí: que Mercado
// Pago confirme el pago no aprueba el pedido solo, siempre requiere que
// el administrador lo revise y apruebe desde el panel (admin/pedidos.php).
if ($pedido_id > 0) {
    $stmt = $conexion->prepare("UPDATE pedidos SET pago_estado = ?, referencia_pago = ? WHERE id = ?");
    $referencia = $payment_id !== '' ? $payment_id : null;
    $stmt->bind_param("ssi", $pagoEstado, $referencia, $pedido_id);
    $stmt->execute();
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resultado del Pago - GMG Repuestos</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        .result-container {
            max-width: 600px;
            margin: 50px auto;
            background: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            text-align: center;
        }
        .icon {
            font-size: 4rem;
            margin-bottom: 20px;
        }
        .success { color: #25D366; }
        .error { color: #D32F2F; }
        .pending { color: #FF9800; }
        .details {
            margin: 20px 0;
            padding: 15px;
            background: #f9f9f9;
            border-radius: 4px;
            text-align: left;
        }
        .btn-volver {
            display: inline-block;
            background: var(--color-principal);
            color: #fff;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 4px;
            font-weight: bold;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <header>
        <div class="container nav-container">
            <a href="index.php" class="logo">GMG <span>Repuestos</span></a>
            <nav>
                <ul>
                    <li><a href="index.php">Inicio</a></li>
                    <li><a href="mi-pedido.php">Mi pedido</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main class="container">
        <div class="result-container">
            <?php if ($aprobado): ?>
                <div class="icon success">✔️</div>
                <h2>¡Compra Confirmada!</h2>
                <p><?php echo $estado_mensaje; ?></p>
                <div class="details">
                    <p><strong>Nº de pedido:</strong> #<?php echo (int)$pedido_id; ?></p>
                    <p><strong>Nº de Operación (Mercado Pago):</strong> <?php echo htmlspecialchars($payment_id); ?></p>
                    <p><strong>Método:</strong> <?php echo htmlspecialchars($payment_type); ?></p>
                </div>
                <p>Guarda tu número de pedido: puedes revisar su estado en cualquier momento en <a href="mi-pedido.php">Estado de mi pedido</a>. En breve nos comunicaremos contigo, o puedes hablarnos por WhatsApp para coordinar tu compra.</p>
                <a href="https://wa.me/56900000000?text=Hola,%20acabo%20de%20comprar%20en%20la%20p%C3%A1gina%20(Pedido%20%23<?php echo (int)$pedido_id; ?>)" class="btn-volver" style="background:#25D366;">Coordinar por WhatsApp</a>
            <?php elseif ($status === 'pending'): ?>
                <div class="icon pending">⏳</div>
                <h2>Pago Pendiente</h2>
                <p><strong>Nº de pedido:</strong> #<?php echo (int)$pedido_id; ?></p>
                <p><?php echo $estado_mensaje; ?></p>
                <a href="index.php" class="btn-volver">Volver a la tienda</a>
            <?php else: ?>
                <div class="icon error">❌</div>
                <h2>Pago Fallido</h2>
                <p><strong>Nº de pedido:</strong> #<?php echo (int)$pedido_id; ?></p>
                <p><?php echo $estado_mensaje; ?></p>
                <a href="index.php" class="btn-volver">Intentar nuevamente</a>
            <?php endif; ?>
        </div>
    </main>
</body>
</html>
