<?php
// Zona horaria del sitio. Sin esto, PHP usa la zona horaria por defecto del
// servidor de Hostinger (normalmente UTC), por lo que las horas mostradas
// (reloj del dashboard, fecha de los pedidos, encabezado "Date" de los
// correos, etc.) quedaban varias horas adelantadas respecto a la hora real
// de Chile. 'America/Santiago' ajusta el horario de verano automáticamente.
date_default_timezone_set('America/Santiago');

// Configuración de la base de datos
// Estos datos los obtienes desde tu panel de Hostinger (hPanel) -> Bases de datos MySQL
$host = "localhost"; // Normalmente es localhost en Hostinger
$usuario = "u118470389_prueba_bd"; // Reemplazar con el usuario creado en hPanel
$contrasena = "PruebaBD2026"; // Reemplazar con la contraseña de la BD
$base_datos = "u118470389_PruebaHpanel"; // Reemplazar con el nombre de la BD

// Desde PHP 8.1 mysqli lanza excepciones ante cualquier error de SQL y eso
// tumba la página completa con "HTTP ERROR 500". El código del sitio revisa
// el resultado de cada consulta (if ($resultado) ...), así que se deja el
// modo clásico: los errores se registran en el log de errores de PHP y la
// consulta simplemente devuelve false.
mysqli_report(MYSQLI_REPORT_ERROR);
// En producción los avisos van solo al log de errores (hPanel > Avanzado >
// Registros de errores), nunca impresos dentro de la página.
ini_set('display_errors', '0');
ini_set('log_errors', '1');

// Intentar la conexión
$conexion = new mysqli($host, $usuario, $contrasena, $base_datos);

// Verificar la conexión
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

// Conjunto de caracteres: utf8mb4, igual que la base de datos v2
// (con "utf8" fallan los emojis y algunos textos con tilde en modo estricto).
$conexion->set_charset("utf8mb4");

// La base de datos también guarda sus propias fechas (por ejemplo
// pedidos.fecha) con la zona horaria del SERVIDOR de MySQL, que es
// independiente de la de PHP y normalmente también está en UTC. Se alinea
// la sesión de MySQL al mismo desfase horario que PHP acaba de calcular
// para Chile (ej. "-03:00" en horario de verano, "-04:00" en invierno), así
// los pedidos nuevos quedan guardados con la hora real de Chile.
$conexion->query("SET time_zone = '" . date('P') . "'");

// Credenciales Mercado Pago
define('MP_PUBLIC_KEY', 'APP_USR-33a1ab25-94fb-4405-af3d-d40547210bda');
define('MP_ACCESS_TOKEN', 'APP_USR-4053025590810751-091422-e5c47cd476e16f378836a1f0fef2c104-3690860500');
?>