<?php
require_once 'backend/config.php';
require_once 'backend/modelos.php';
require_once 'backend/datos.php';

$productos = [];
$mostrarSelector = true; // Por defecto mostramos las tarjetas de autos
$categoriasDisponibles = [];

// Modelos que realmente tienen productos cargados (dinámico: se arma
// solo, sin tocar código, apenas el admin carga el primer producto de un
// modelo nuevo). $modelosInfo trae, para cada uno, su nombre completo,
// su nombre corto (el que se usa en la URL y el buscador) y su imagen.
$modelosInfo = [];
$modelosCortosTexto = 'todos los modelos Suzuki';

if (isset($conexion) && !$conexion->connect_error) {
    foreach (gmgModelosConProductos($conexion) as $modeloCompleto) {
        $imagenModelo = gmgModeloImagen($modeloCompleto);
        $resumenModelo = gmgModeloResumen($modeloCompleto);
        $modelosInfo[] = [
            'completo' => $modeloCompleto,
            'corto' => gmgModeloCorto($modeloCompleto),
            'imagen' => $imagenModelo,
            'tiene_foto' => strpos($imagenModelo, 'placeholder-modelo') === false,
            'repuestos' => $resumenModelo['repuestos'],
            'anios' => $resumenModelo['anios'],
        ];
    }
    if (count($modelosInfo) > 0) {
        $modelosCortosTexto = gmgUnirConY(array_column($modelosInfo, 'corto'));
    }

    // Categorías con al menos un repuesto activo, para el filtro del buscador (siempre visible)
    $resCategorias = $conexion->query("SELECT c.nombre FROM categorias c
                                        WHERE EXISTS (SELECT 1 FROM repuestos r WHERE r.id_categoria = c.id_categoria AND r.activo = 1)
                                        ORDER BY c.orden, c.nombre");
    if ($resCategorias) {
        while ($filaCategoria = $resCategorias->fetch_assoc()) {
            $categoriasDisponibles[] = $filaCategoria['nombre'];
        }
    }

    // Si hay una búsqueda, un modelo o una categoría seleccionada, ocultamos el selector y buscamos repuestos
    if (!empty($_GET['modelo']) || !empty($_GET['q']) || !empty($_GET['categoria'])) {
        $mostrarSelector = false;

        // Base v2: los repuestos se filtran por modelo a través de la tabla
        // compatibilidades (un repuesto puede servir a varios modelos).
        $sql = "SELECT * FROM " . gmgSqlProductos() . " p";
        $where = ["p.activo = 1"];

        if (!empty($_GET['modelo'])) {
            $where[] = gmgCondicionModelo($conexion, $_GET['modelo'], 'p.id');
        }
        if (!empty($_GET['categoria'])) {
            $where[] = "p.categoria = '" . $conexion->real_escape_string($_GET['categoria']) . "'";
        }
        if (!empty($_GET['q'])) {
            // Busca por nombre O por código SKU / OEM exacto o parcial (ej: FRE-SWI3-PDL)
            $qEscapado = $conexion->real_escape_string($_GET['q']);
            $where[] = "(p.nombre LIKE '%$qEscapado%' OR p.sku LIKE '%$qEscapado%' OR p.codigo_oem LIKE '%$qEscapado%')";
        }

        $sql .= " WHERE " . implode(" AND ", $where) . " ORDER BY p.categoria, p.nombre";

        $resultado = $conexion->query($sql);
        if ($resultado && $resultado->num_rows > 0) {
            while($fila = $resultado->fetch_assoc()) {
                $productos[] = $fila;
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GMG Repuestos SpA - Especialistas en Suzuki</title>
    <link rel="stylesheet" href="css/style.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="css/chat.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="css/model-carousel.css?v=<?php echo time(); ?>">
</head>
<body>

    <header>
        <div class="container nav-container">
            <a href="index.php" class="logo">GMG <span>Repuestos</span></a>
            <nav>
                <ul>
                    <li><a href="index.php">Inicio</a></li>
                    <li><a href="mi-pedido.php">Mi pedido</a></li>
                    <li>
                        <a href="#" id="cart-toggle" class="cart-toggle">
                            🛒 <span id="cart-count" class="cart-count">0</span>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="critical-rule">
        ⚠️ REGLA CRÍTICA: Por favor confirma la compatibilidad de tu repuesto con nosotros vía WhatsApp antes de comprar para evitar errores.
    </div>

    <!-- Barra de búsqueda siempre visible -->
    <section class="search-section">
        <div class="container">
            <form action="index.php" method="GET" class="search-form" id="searchForm" autocomplete="off">
                <div class="search-input-wrap">
                    <input type="text" name="q" id="searchInput" placeholder="Buscar por nombre o código SKU (ej: FRE-SWI3-PDL)" value="<?php echo isset($_GET['q']) ? htmlspecialchars($_GET['q']) : ''; ?>">
                    <div id="searchSugerencias" class="search-sugerencias"></div>
                </div>
                <select name="modelo">
                    <option value="">Todos los modelos</option>
                    <?php foreach ($modelosInfo as $mi): ?>
                        <option value="<?php echo htmlspecialchars($mi['corto']); ?>" <?php echo (isset($_GET['modelo']) && $_GET['modelo'] == $mi['corto']) ? 'selected' : ''; ?>><?php echo htmlspecialchars($mi['completo']); ?></option>
                    <?php endforeach; ?>
                </select>
                <select name="categoria">
                    <option value="">Todas las categorías</option>
                    <?php foreach ($categoriasDisponibles as $categoriaOpcion): ?>
                        <option value="<?php echo htmlspecialchars($categoriaOpcion); ?>" <?php echo (isset($_GET['categoria']) && $_GET['categoria'] === $categoriaOpcion) ? 'selected' : ''; ?>><?php echo htmlspecialchars($categoriaOpcion); ?></option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" class="btn-search">Buscar</button>
            </form>
        </div>
    </section>

    <main class="container">

        <?php if ($mostrarSelector): ?>
            <!-- ESTADO 1: SELECTOR DE MODELOS -->
            <section class="hero-carousel" id="heroCarousel">
                <div class="hero-track">
                    <div class="hero-slide is-active">
                        <div class="hero-band-inner">
                            <h1 class="hero-title">Repuestos <span>Suzuki</span> al instante</h1>
                            <p class="hero-subtitle">Piezas originales y compatibles para <?php echo htmlspecialchars($modelosCortosTexto); ?>. Encuentra lo que buscas y coordina tu compra directo por WhatsApp.</p>
                        </div>
                    </div>
                    <div class="hero-slide">
                        <div class="hero-band-inner">
                            <h1 class="hero-title">Compra <span>rápido</span>, sin vueltas</h1>
                            <p class="hero-subtitle">Usa "Comprar ahora" en cualquier repuesto y paga directo con Mercado Pago en pocos clics, sin pasos de más.</p>
                        </div>
                    </div>
                    <div class="hero-slide">
                        <div class="hero-band-inner">
                            <h1 class="hero-title">Busca por <span>SKU</span> exacto</h1>
                            <p class="hero-subtitle">¿Ya tienes el código de tu repuesto? Escríbelo en el buscador y aparecerán sugerencias al instante.</p>
                        </div>
                    </div>
                </div>
                <div class="hero-dots">
                    <button type="button" class="hero-dot is-active" data-hero-index="0" aria-label="Slide 1"></button>
                    <button type="button" class="hero-dot" data-hero-index="1" aria-label="Slide 2"></button>
                    <button type="button" class="hero-dot" data-hero-index="2" aria-label="Slide 3"></button>
                </div>
            </section>

            <section class="gmg-chat-promo">
                <div class="gmg-chat-promo-icon">🤖</div>
                <div class="gmg-chat-promo-texto">
                    <h3>¿No encuentras tu repuesto?</h3>
                    <p>Pregúntale a nuestro Asistente Virtual con IA: identifica piezas por foto, busca en el catálogo en tiempo real y te ayuda a comprar sin salir del chat.</p>
                </div>
                <button type="button" id="gmgHomeChatCTA" class="gmg-chat-promo-btn">Hablar con el Asistente</button>
            </section>

            <h2 class="section-title">Selecciona tu modelo Suzuki</h2>

            <?php if (count($modelosInfo) > 0): ?>
                <!-- Carrusel de modelos: avanza solo con las flechas, los puntos,
                     el teclado o deslizando con el dedo (nunca automático). -->
                <div class="model-carousel" id="modelCarousel" role="region" aria-roledescription="carrusel" aria-label="Modelos Suzuki">
                    <button type="button" class="mc-nav mc-nav--prev" aria-label="Ver modelos anteriores" hidden>
                        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M15 18l-6-6 6-6"/></svg>
                    </button>
                    <div class="mc-track" tabindex="0">
                        <?php foreach ($modelosInfo as $mi): ?>
                            <a href="index.php?modelo=<?php echo urlencode($mi['corto']); ?>"
                               class="mc-card"
                               aria-label="Ver repuestos para <?php echo htmlspecialchars($mi['completo']); ?>">
                                <span class="mc-card__media<?php echo $mi['tiene_foto'] ? '' : ' mc-card__media--sin-foto'; ?>">
                                    <span class="mc-card__placeholder" aria-hidden="true">
                                        <svg viewBox="0 0 120 52"><path d="M6 36v-6c0-4 3-7 9-8l18-2 12-10c2-2 5-3 9-3h24c5 0 8 1 11 4l11 10 10 2c5 1 8 4 8 9v4z"/><circle cx="31" cy="38" r="9"/><circle cx="31" cy="38" r="4"/><circle cx="91" cy="38" r="9"/><circle cx="91" cy="38" r="4"/></svg>
                                        <span>Foto próximamente</span>
                                    </span>
                                    <?php if ($mi['tiene_foto']): ?>
                                        <img class="mc-card__img" src="<?php echo htmlspecialchars($mi['imagen']); ?>" alt="<?php echo htmlspecialchars($mi['completo']); ?>" loading="lazy" draggable="false" onerror="this.parentNode.classList.add('mc-card__media--sin-foto');this.remove();">
                                    <?php endif; ?>
                                </span>
                                <span class="mc-card__body">
                                    <span class="mc-card__marca">Suzuki</span>
                                    <span class="mc-card__nombre"><?php echo htmlspecialchars($mi['corto']); ?></span>
                                    <span class="mc-card__meta">
                                        <?php echo (int)$mi['repuestos']; ?> repuestos<?php if ($mi['anios'] !== ''): ?> · <?php echo htmlspecialchars($mi['anios']); ?><?php endif; ?>
                                    </span>
                                    <span class="mc-card__cta">Ver repuestos <span aria-hidden="true">→</span></span>
                                </span>
                            </a>
                        <?php endforeach; ?>
                    </div>
                    <button type="button" class="mc-nav mc-nav--next" aria-label="Ver más modelos" hidden>
                        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 6l6 6-6 6"/></svg>
                    </button>
                    <div class="mc-dots" aria-label="Páginas del carrusel"></div>
                </div>
            <?php else: ?>
                <p style="color:#888; text-align:center; margin: 20px 0;">Todavía no hay productos cargados. Vuelve pronto.</p>
            <?php endif; ?>

        <?php else: ?>
            <!-- ESTADO 2: CATÁLOGO DE REPUESTOS -->
            <a href="index.php" class="btn-back">← Volver a todos los modelos</a>

            <?php
                $tituloCatálogo = "Repuestos Disponibles";
                if (!empty($_GET['modelo'])) {
                    $tituloCatálogo = "Repuestos para Suzuki " . htmlspecialchars($_GET['modelo']);
                }
                if (!empty($_GET['q'])) {
                    $tituloCatálogo .= " - Búsqueda: '" . htmlspecialchars($_GET['q']) . "'";
                }
            ?>
            <h2><?php echo $tituloCatálogo; ?></h2>

            <?php if (count($productos) > 0): ?>
                <div class="productos-grid">
                    <?php foreach($productos as $producto): ?>
                    <?php
                        $imagenes = [$producto['imagen_url']];
                        if (!empty($producto['imagen_url_2'])) { $imagenes[] = $producto['imagen_url_2']; }
                        if (!empty($producto['imagen_url_3'])) { $imagenes[] = $producto['imagen_url_3']; }
                        $numImagenes = count($imagenes);
                    ?>
                    <div class="producto-card">
                        <div class="producto-img-wrap">
                            <?php foreach ($imagenes as $i => $urlImagen): ?>
                                <img src="<?php echo htmlspecialchars($urlImagen); ?>" alt="<?php echo htmlspecialchars($producto['nombre']); ?>" class="producto-img<?php echo $i === 0 ? ' producto-img-activa' : ''; ?>" data-index="<?php echo $i; ?>" loading="lazy" onerror="this.onerror=null;this.src='img/placeholder-repuesto.svg';">
                            <?php endforeach; ?>
                            <?php if ($numImagenes > 1): ?>
                                <button type="button" class="producto-img-nav producto-img-prev" aria-label="Foto anterior">‹</button>
                                <button type="button" class="producto-img-nav producto-img-next" aria-label="Foto siguiente">›</button>
                                <div class="producto-img-dots">
                                    <?php for ($i = 0; $i < $numImagenes; $i++): ?>
                                        <span class="producto-img-dot<?php echo $i === 0 ? ' is-active' : ''; ?>" data-index="<?php echo $i; ?>"></span>
                                    <?php endfor; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="producto-info">
                            <div class="producto-categoria"><?php echo htmlspecialchars($producto['categoria']); ?></div>
                            <h3 class="producto-nombre"><?php echo htmlspecialchars($producto['nombre']); ?></h3>
                            <div class="producto-detalles">
                                <p><strong>Modelo:</strong> <?php echo htmlspecialchars($producto['modelo'] ?? ''); ?></p>
                                <p><strong>Año:</strong> <?php echo htmlspecialchars($producto['ano'] ?? ''); ?></p>
                                <p><strong>SKU:</strong> <?php echo htmlspecialchars($producto['sku']); ?></p>
                                <?php if (!empty($producto['compatible_con'])): ?>
                                    <?php $vehiculosCompatibles = explode('; ', $producto['compatible_con']); ?>
                                    <details class="producto-compat">
                                        <summary>Vehículos compatibles (<?php echo count($vehiculosCompatibles); ?>)</summary>
                                        <ul>
                                            <?php foreach ($vehiculosCompatibles as $vehiculoCompatible): ?>
                                                <li><?php echo htmlspecialchars($vehiculoCompatible); ?></li>
                                            <?php endforeach; ?>
                                        </ul>
                                    </details>
                                <?php endif; ?>
                            </div>
                            <div class="producto-precio">$<?php echo number_format($producto['precio'], 0, ',', '.'); ?> CLP</div>

                            <div class="producto-acciones">
                                <button class="btn-add-cart"
                                        data-id="<?php echo htmlspecialchars($producto['id']); ?>"
                                        data-nombre="<?php echo htmlspecialchars($producto['nombre']); ?>"
                                        data-precio="<?php echo htmlspecialchars($producto['precio']); ?>"
                                        data-imagen="<?php echo htmlspecialchars($producto['imagen_url']); ?>"
                                        data-categoria="<?php echo htmlspecialchars($producto['categoria']); ?>">
                                    🛒 Añadir al carrito
                                </button>
                                <button class="btn-comprar-ahora"
                                        data-id="<?php echo htmlspecialchars($producto['id']); ?>"
                                        data-nombre="<?php echo htmlspecialchars($producto['nombre']); ?>"
                                        data-precio="<?php echo htmlspecialchars($producto['precio']); ?>"
                                        data-imagen="<?php echo htmlspecialchars($producto['imagen_url']); ?>"
                                        data-categoria="<?php echo htmlspecialchars($producto['categoria']); ?>">
                                    ⚡ Comprar ahora
                                </button>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <p style="margin-top: 20px; font-size: 1.2rem; color: #666;">No se encontraron repuestos para tu búsqueda. Intenta consultarle a nuestro Asistente Virtual.</p>
            <?php endif; ?>

        <?php endif; ?>

    </main>

    <footer>
        <div class="container footer-grid">
            <div class="footer-col footer-brand">
                <div class="footer-logo">GMG <span>Repuestos</span></div>
                <p class="footer-desc">Especialistas en repuestos originales y compatibles para <?php echo htmlspecialchars($modelosCortosTexto); ?>. Piezas de calidad, con garantía, coordinando cada compra directo por WhatsApp.</p>
            </div>

            <div class="footer-col">
                <h4 class="footer-heading">Modelos</h4>
                <ul class="footer-links">
                    <?php foreach ($modelosInfo as $mi): ?>
                        <li><a href="index.php?modelo=<?php echo urlencode($mi['corto']); ?>"><?php echo htmlspecialchars($mi['completo']); ?></a></li>
                    <?php endforeach; ?>
                </ul>
            </div>

            <div class="footer-col">
                <h4 class="footer-heading">Contacto</h4>
                <ul class="footer-contact">
                    <li>📍 Av. Providencia 1234, Providencia, Santiago</li>
                    <li>📞 +56 9 1234 5678</li>
                    <li>✉️ contacto@gmgrepuestos.cl</li>
                    <li>🕒 Lunes a viernes, 9:00 - 18:30</li>
                </ul>
            </div>
        </div>

        <div class="footer-bottom">
            <div class="container footer-bottom-inner">
                <p>&copy; <?php echo date('Y'); ?> GMG Repuestos SpA. Especialistas en repuestos Suzuki en Chile.</p>
                <a href="login.php" class="footer-admin-link">Acceso administrador</a>
            </div>
        </div>
    </footer>

    <!-- Botón Flotante del Chatbot IA -->
    <div id="gmgChatToggle" class="gmg-chat-toggle" title="Abrir Asistente Virtual GMG">
        <span class="chat-badge"></span>
        <svg viewBox="0 0 24 24">
            <path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 14H6l-2 2V4h16v12z"/>
        </svg>
    </div>

    <!-- Ventana del Chatbot IA -->
    <div id="gmgChatWindow" class="gmg-chat-window">
        <!-- ... (Contenido del chat sin alterar) ... -->
        <div class="gmg-chat-header">
            <div class="gmg-chat-header-info">
                <div class="gmg-chat-avatar">GMG</div>
                <div class="gmg-chat-title">
                    <h4>Asistente GMG (IA)</h4>
                    <p>Especialista en línea</p>
                </div>
            </div>
            <div class="gmg-chat-header-actions">
                <button id="gmgChatClose" class="gmg-chat-close-btn" title="Minimizar chat">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <line x1="18" y1="6" x2="6" y2="18"></line>
                        <line x1="6" y1="6" x2="18" y2="18"></line>
                    </svg>
                </button>
            </div>
        </div>

        <div id="gmgChatMessages" class="gmg-chat-messages">
            <div class="gmg-msg gmg-msg-bot">
                <div class="gmg-msg-bubble">
                    <p>¡Hola! 👋 Soy tu <strong>Asistente Virtual GMG</strong> especialista en repuestos Suzuki (<?php echo htmlspecialchars($modelosCortosTexto); ?>).</p>
                    <p>¿En qué te puedo ayudar hoy? Puedes consultarme por precios, disponibilidad, subir hasta <strong>3 fotos</strong> de la pieza que necesitas, o dictar tu consulta por voz.</p>
                </div>
                <span class="gmg-msg-time">Ahora</span>
            </div>
        </div>

        <div class="gmg-quick-chips">
            <button type="button" class="gmg-chip" data-prompt="¿Tienen pastillas de freno para Suzuki Swift?">🔍 Pastillas Swift</button>
            <button type="button" class="gmg-chip" data-prompt="Busco filtro de aceite para Suzuki Alto">🛢️ Filtro Alto</button>
            <button type="button" class="gmg-chip" data-prompt="¿Tienen amortiguador para Suzuki S-Presso?">🚗 S-Presso</button>
            <button type="button" class="gmg-chip" data-action="upload" data-prompt="Subir foto">📸 Enviar foto</button>
        </div>

        <div id="gmgChatPreviewBar" class="gmg-chat-image-preview-bar">
            <div id="gmgChatPreviewList" class="gmg-chat-preview-list"></div>
        </div>

        <div class="gmg-chat-footer">
            <input type="file" id="gmgChatFileInput" accept="image/*" multiple style="display: none;">
            <button type="button" id="gmgChatFileBtn" class="gmg-chat-file-btn" title="Adjuntar hasta 3 fotos de la pieza">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"></path>
                    <circle cx="12" cy="13" r="4"></circle>
                </svg>
            </button>
            <button type="button" id="gmgChatMicBtn" class="gmg-chat-file-btn gmg-chat-mic-btn" title="Consultar por voz" style="display:none;">
                <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"></path>
                    <path d="M19 10v2a7 7 0 0 1-14 0v-2"></path>
                    <line x1="12" y1="19" x2="12" y2="23"></line>
                    <line x1="8" y1="23" x2="16" y2="23"></line>
                </svg>
            </button>
            <input type="text" id="gmgChatInput" class="gmg-chat-input" placeholder="Escribe tu consulta..." autocomplete="off">
            <button type="button" id="gmgChatSend" class="gmg-chat-send-btn" title="Enviar mensaje">
                <svg viewBox="0 0 24 24">
                    <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"></path>
                </svg>
            </button>
        </div>
    </div>

    <!-- Panel Lateral del Carrito -->
    <div id="cart-sidebar" class="cart-sidebar">
        <div class="cart-header">
            <h3>Tu Carrito</h3>
            <button id="close-cart" class="close-cart">&times;</button>
        </div>
        <div class="cart-select-all-row" id="cartSelectAllRow" style="display:none;">
            <label class="cart-checkbox-label">
                <input type="checkbox" id="cartSelectAll" checked>
                Seleccionar todos
            </label>
        </div>
        <div id="cart-items" class="cart-items"></div>
        <div id="cart-guardados" class="cart-guardados"></div>
        <div id="cart-relacionados" class="cart-relacionados"></div>
        <div class="cart-footer">
            <div class="cart-promo">
                <input type="text" id="promoInput" placeholder="Código de descuento" autocomplete="off">
                <button type="button" id="btnAplicarPromo">Aplicar</button>
            </div>
            <div id="promoMensaje" class="cart-promo-msg"></div>
            <div class="cart-subtotal-row" id="cartSubtotalRow" style="display:none;">
                <span>Subtotal:</span><span id="cart-subtotal-price">$0</span>
            </div>
            <div class="cart-descuento-row" id="cartDescuentoRow" style="display:none;">
                <span>Descuento:</span><span id="cart-descuento-price">-$0</span>
            </div>
            <div class="cart-total">
                <span>Total:</span>
                <span id="cart-total-price">$0</span>
            </div>
            <button id="btn-checkout" class="btn-checkout" style="background:#009ee3;">Pagar con Mercado Pago</button>
            <div id="checkout-spinner" style="display:none; text-align:center; padding: 10px;">Procesando...</div>
        </div>
    </div>
    <div id="cart-overlay" class="cart-overlay"></div>

    <!-- Modal de datos del cliente (previo al pago) -->
    <div id="clienteModalOverlay" class="cliente-modal-overlay">
        <div class="cliente-modal">
            <button type="button" id="clienteModalClose" class="cliente-modal-close" aria-label="Cerrar">&times;</button>
            <h3>Un último paso</h3>
            <p class="cliente-modal-sub">Necesitamos estos datos para coordinar tu compra. GMG Repuestos no realiza envíos: coordinamos contigo la entrega por WhatsApp.</p>
            <form id="clienteForm" class="cliente-form">
                <div class="cliente-form-row">
                    <div>
                        <label for="clienteNombre">Nombre</label>
                        <input type="text" id="clienteNombre" required>
                    </div>
                    <div>
                        <label for="clienteApellido">Apellido</label>
                        <input type="text" id="clienteApellido" required>
                    </div>
                </div>
                <div class="cliente-form-row">
                    <div>
                        <label for="clienteRut">RUT</label>
                        <input type="text" id="clienteRut" placeholder="12.345.678-9" required>
                    </div>
                    <div>
                        <label for="clienteTelefono">Teléfono</label>
                        <input type="text" id="clienteTelefono" placeholder="+56 9 1234 5678" required>
                    </div>
                </div>
                <div class="cliente-form-row">
                    <div class="cliente-form-full">
                        <label for="clienteEmail">Correo electrónico</label>
                        <input type="email" id="clienteEmail" placeholder="tucorreo@ejemplo.cl" required>
                    </div>
                </div>
                <p class="cliente-form-nota">Te avisaremos por este correo cuando tu pedido sea aprobado o si hay algún problema con el pago.</p>
                <div id="clienteFormError" class="cliente-form-error" style="display:none;"></div>
                <button type="submit" class="btn-checkout" id="btnConfirmarCliente">Continuar al pago</button>
                <div id="clienteFormSpinner" style="display:none; text-align:center; padding: 10px;">Procesando...</div>
            </form>
        </div>
    </div>

    <script src="js/cart.js?v=<?php echo time(); ?>"></script>
    <script src="js/tienda.js?v=<?php echo time(); ?>"></script>
    <script src="js/chat.js?v=<?php echo time(); ?>"></script>
    <script src="js/model-carousel.js?v=<?php echo time(); ?>"></script>
</body>
</html>
